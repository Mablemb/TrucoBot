import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Deque
{

    private ArrayList<Carta> cartas = new ArrayList<Carta>(); // Todas as cartas do truco

    //Construtor cria um deque com todas as cartas, ordenadas conforme a lista naipes

    public Deque()
    {
        ArrayList<Carta> novoDeque = new ArrayList<Carta>();

        String[] numeros = {"4", "5", "6", "7", "J", "Q", "K", "A", "2", "3"};   // Valores usados no truco
        String[] naipes = {"♦", "♠", "♥", "♣"};                            // Naipes do baralho
        int[] valores = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};                         // Valores para comparação entre cartas
        List<String> manilhas = Arrays.asList("♦7", "♠A", "♥7", "♣4");

        for (String naipe : naipes) {
            for (int i = 0; i < numeros.length; i++) {
                Carta carta = new Carta(naipe, numeros[i], valores[i]);

                if (manilhas.contains(naipe + numeros[i])) {
                    switch (carta.getNaipe()) {
                        case "♦":
                            carta.setValor(11);
                            break;
                        case "♠":
                            carta.setValor(12);
                            break;
                        case "♥":
                            carta.setValor(13);
                            break;
                        case "♣":
                            carta.setValor(14);
                            break;
                    }
                    carta.setIsManilha(true);
                }
                novoDeque.add(carta);
            }
        }
        this.cartas = novoDeque;
    }

    public ArrayList<Carta> embaralhar()
    {
        Collections.shuffle(this.cartas);
        return this.cartas;
    }

    public ArrayList<Carta> getCartas() {
        return cartas;
    }

    public void setCartas(ArrayList<Carta> cartas) {
        this.cartas = cartas;
    }
}