import java.util.ArrayList;
import java.util.Collections;

public class Jogador {

    private String nome;
    private int pontos;

    private ArrayList<Carta> mao = new ArrayList<Carta>();

    public void distribuirCartas(ArrayList<Jogador> jogadores, ArrayList<Carta> deque)
    {
        for(int i = 0; i < 4; i++) {
            for (int j = 0; j < 3;j++) {
                jogadores.get(i).mao.add(deque.get(0));
                deque.remove(0);
            }
            System.out.println(jogadores.get(i).getNome() + " recebeu 3 cartas.");
        }
    };

    public String getNome() {
        return nome;
    }

    public int getPontos() {
        return pontos;
    }

    public ArrayList<Carta> getMao() {
        return mao;
    }
}
