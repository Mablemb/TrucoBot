import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        ArrayList<Jogador> jogadores = new ArrayList<Jogador>();

        Jogador player1 = new Jogador();
        Jogador player2 = new Jogador();
        Jogador player3 = new Jogador();
        Jogador player4 = new Jogador();

        jogadores.add(player1);
        jogadores.add(player2);
        jogadores.add(player3);
        jogadores.add(player4);

        Deque deque = new Deque();

        deque.embaralhar();

        for (int i = 0; i < 5; i++)
            System.out.println(deque.getCartas().get(i).getNaipe()+deque.getCartas().get(i).getNumero());
    }
}
