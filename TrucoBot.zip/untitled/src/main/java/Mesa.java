import java.util.ArrayList;

public class Mesa {

    Deque deque;
    ArrayList<Jogador> jogadores;
    ArrayList<Carta> cartasNaMesa;s

    public Mesa() {
    }

    while(ponts < 12)
        While(cartasnamesa < 4)

        /*
      while (etapas<3) {
    switch(vez){
        case 0:

        case 1:
            cartasNaMesa.add();
            vez ++;
        case 2:
            cartasNaMesa.add();
            vez ++;
        case 3:
            cartasNaMesa.add();
            vez ++;
        case 4:
            cartasNaMesa.add();
            vez =0;
            break;
         }
                }
               ----------------------

               Jogador vez []= {1,2,3,4};
        */
    }

}
